/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: true,
  // reactStrictMode: false,
  // target: 'serverless',
  images: {
    domains: ['images.ctfassets.net'],
},
}
