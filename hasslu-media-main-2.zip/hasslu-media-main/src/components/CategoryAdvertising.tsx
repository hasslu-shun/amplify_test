import styles from 'styles/CategoryAdvertising.module.scss'

const CategoryAdvertising = () => {
  return (
    <div className={styles.container}>
      <div className={styles.main}>test1</div>
      <div className={styles.main}>test2</div>
    </div>
  )
}

export default CategoryAdvertising
