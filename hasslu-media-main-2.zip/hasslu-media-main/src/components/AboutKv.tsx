import styles from 'styles/AboutKv.module.scss'

const AboutKv = () => {
  return (
    <section className={styles.container}>
      <h1 className={styles.title}>it is such a hassle to ...</h1>
      <div className={styles.bgEn}>
        <span className={styles.bgEnText}>
          it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ... it
          is such a hassle to ... it is such a hassle to ... it is such a hassle
          to ... it is such a hassle to ... it is such a hassle to ... it is
          such a hassle to ... it is such a hassle to ... it is such a hassle to
          ... it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ...
        </span>
        <span className={styles.bgEnText}>
          it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ... it
          is such a hassle to ... it is such a hassle to ... it is such a hassle
          to ... it is such a hassle to ... it is such a hassle to ... it is
          such a hassle to ... it is such a hassle to ... it is such a hassle to
          ... it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ...
        </span>
      </div>
      <div className={styles.bgEn}>
        <span className={styles.bgEnText}>
          it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ... it
          is such a hassle to ... it is such a hassle to ... it is such a hassle
          to ... it is such a hassle to ... it is such a hassle to ... it is
          such a hassle to ... it is such a hassle to ... it is such a hassle to
          ... it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ...
        </span>
        <span className={styles.bgEnText}>
          it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ... it
          is such a hassle to ... it is such a hassle to ... it is such a hassle
          to ... it is such a hassle to ... it is such a hassle to ... it is
          such a hassle to ... it is such a hassle to ... it is such a hassle to
          ... it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ...
        </span>
      </div>
      {/* <div className={styles.bgEn}>
        <span className={styles.bgEnText}>
          マジでめんどくさい…
          めんどくさすぎ…　働くのめんどくさい…　仕事めんどくさい…　考えるのめんどくさい…
          マジでめんどくさい…
          めんどくさすぎ…　働くのめんどくさい…　仕事めんどくさい…　考えるのめんどくさい…
          マジでめんどくさい…
          めんどくさすぎ…　働くのめんどくさい…　仕事めんどくさい…　考えるのめんどくさい…
        </span>
      </div> */}
      {/* <div className={styles.bgEn}>
        <span className={styles.bgEnText}>
          it is such a hassle to ... it is such a hassle to ... it is such a
          hassle to ... it is such a hassle to ... it is such a hassle to ... it
          is such a hassle to ... it is such a hassle to ... it is such a hassle
          to ... it is such a hassle to ...
        </span>
      </div> */}
    </section>
  )
}

export default AboutKv
